const { question } = require('readline-sync');
var readlineSync = require('readline-sync');

var operator = '';
var firstNum = null;
var secondNum = null;

function isItAnOperator(z) {
    if (z === "+" ||
        z === "-" ||
        z === "*" ||
        z === "/" ||
        z === "%") {
        console.log("You have chosen " + z + "!");
        return operator = z;
    } else {
        console.log('Oops, that wasn\'t an Operator. Please try again');
        var tryAgain = readlineSync.question('Please enter one of the following: x , - , * , / or %. Nothing else please.');
        return isItAnOperator(tryAgain);
    }
}
function isItANumberOne(x) {
    if (x !== NaN) {
        console.log("You have chosen " + x + "!");
        return firstNum = x;
    }
}
function isItANumberTwo(y) {
    if (y !== NaN) {
        console.log("You have chosen " + y + "!");
        return secondNum = y;
    }
}

var isOperator = readlineSync.question('Please enter an operator: + , - , * , / or % only.');
isItAnOperator(isOperator);
var isNumOne = readlineSync.questionFloat('What is your first number?');
isItANumberOne(isNumOne);
var isNumTwo = readlineSync.questionFloat('What is your second number?');
isItANumberTwo(isNumTwo);

console.log('You have selected ' + `${firstNum}` + `${operator}` + `${secondNum}` + '!');
console.log("Hmmm... Let me think...");

function theOperation(op, first, second) {
    if (op === "+") {
        return results = first + second;
    } else if (op === "-") {
        return results = first - second;
    } else if (op === "*") {
        return results = first * second;
    } else if (op === "/") {
        return results = first / second;
    } else if (op === "%") {
        return results = first % second;
    };

}

console.log('The result is ' + theOperation(operator, firstNum, secondNum) + '!');
